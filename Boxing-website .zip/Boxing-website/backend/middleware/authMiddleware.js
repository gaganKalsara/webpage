const jwt = require('jsonwebtoken'); // Ensure jwt is imported

// Verify if the user is authenticated
const verifyUser = (req, res, next) => {
    const token = req.cookies.token;
    if (!token) {
        return res.status(401).json({ error: "No token provided" });
    }
    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => { // Use the correct JWT secret
        if (err) {
            return res.status(401).json({ error: "Invalid token" });
        }
        req.user = decoded; // Attach the decoded user info to the request
        next();
    });
};

module.exports = { verifyUser };
