// BoxChamp.jsx
import React from 'react';
import './Boxchamp.css';



const BoxChamp = () => {
    return (
      <div className="landing-container">
       
        <div className="content-wrapper">
          <div className="text-content">
            <h1 className="main-title">
              WE  ARE  TEAM OF 
              <br />
              <div className="underline"></div> {/* This is the line under the text */}
              
            
              <span className="highlight-text">BOXCHAMP</span>
            </h1>
            
            <p className="description">
              For your boxing tools selling company, BoxChamp is a strong and 
              fitting name. It combines the essence of the sport ("Box") with 
              the idea of being a champion ("Champ"), giving your brand a 
              powerful, competitive edge.
            </p>
            
            <p className="description">
              This name suggests quality, reliability, and a commitment to 
              helping boxers reach their peak performance. It's short, 
              memorable, and perfect for a business that aims to equip 
              champions.
            </p>
            
            <button className="more-button">
              MORE <span className="arrow">→</span>
            </button>
          </div>
        </div>
        
      </div>
    );
  };
  
  export default BoxChamp;
  