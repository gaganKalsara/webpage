import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './navbar.css';
import myImage from '../images/download.png';
import { LogOut } from 'lucide-react';

const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const checkLoginStatus = async () => {
            try {
                const res = await axios.get("http://localhost:5000/home", { withCredentials: true });
                if (res.status === 200) {
                    setIsLoggedIn(true);
                }
            } catch (err) {
                setIsLoggedIn(false);
            }
        };
        checkLoginStatus();
    }, []);

    const toggleMenu = () => {
        setIsOpen(!isOpen);
    };

    const handleLogout = async () => {
        try {
            await axios.post("http://localhost:5000/logout", {}, { withCredentials: true });
            setIsLoggedIn(false);
            navigate('/');
        } catch (err) {
            console.error("Logout failed:", err);
        }
    };

    return (
        <nav className="navbar">
            <div className="image-container">
                <img src={myImage} alt="My Logo" />
                <h3>BOXCHAMPY</h3>
            </div>
            <div className={`menu-icon ${isOpen ? 'open' : ''}`} onClick={toggleMenu}>
                &#9776;
            </div>
            <ul className={`nav-links ${isOpen ? 'open' : ''}`}>
                <li><Link to="/">HOME</Link></li>
                <li><Link to="/shop">SHOP</Link></li>
                <li><Link to="/about">ABOUT</Link></li>
                <li>
                    {isLoggedIn ? (
                        <button className="sign-up-button" onClick={handleLogout}>
                            <LogOut size={20} />
                        </button>
                    ) : (
                        <Link to="/login">
                            <button className="sign-up-button">
                                SIGN UP
                            </button>
                        </Link>
                    )}
                </li>
            </ul>
        </nav>
    );
};

export default Navbar;