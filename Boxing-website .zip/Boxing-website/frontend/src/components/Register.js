import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/register", { name, email, password });
      if (res.status === 201) {
        navigate("/login"); // Redirect to login after successful registration
      }
    } catch (err) {
      setError("Registration failed. Please try again.");
    }
  };

  return (
    <div style={styles.background}>
      <div style={styles.registerContainer}>
        <h2 style={styles.title}>CREATE ACCOUNT</h2>
        {error && <p style={styles.error}>{error}</p>}
        <form onSubmit={handleSubmit} style={styles.form}>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            placeholder="Name"
            style={styles.input}
          />
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            placeholder="Email Address"
            style={styles.input}
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            placeholder="Password"
            style={styles.input}
          />
          <button type="submit" style={styles.button}>CREATE NOW</button>
        </form>
      </div>
    </div>
  );
};

const styles = {
  background: {
    backgroundColor: '#4a2828',
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  registerContainer: {
    backgroundColor: 'white',
    padding: '60px',
    borderRadius: '30px',
    width: '600px',
    boxShadow: '0 6px 10px rgba(0, 0, 0, 0.1)',
  },
  title: {
    textAlign: 'center',
    marginBottom: '40px',
    color: '#333',
    fontWeight: 'bold',
    fontSize: '36px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
  },
  input: {
    marginBottom: '30px',
    padding: '20px',
    border: '1px solid #ddd',
    borderRadius: '10px',
    fontSize: '20px',
  },
  button: {
    backgroundColor: '#ff3b3b',
    color: 'white',
    padding: '20px',
    border: 'none',
    borderRadius: '10px',
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: '24px',
    textTransform: 'uppercase',
  },
  error: {
    color: 'red',
    textAlign: 'center',
    marginBottom: '20px',
    fontSize: '18px',
  },
};

export default Register;