import React from 'react';
 
import myImage from '../images/1.jpg'; // Main image
import smallImage1 from '../images/2.png'; // Small image 1
import smallImage2 from '../images/3.webp'; // Small image 2
import smallImage3 from '../images/4.webp'; // Small image 3
import newImage from '../images/5.webp'; // New image to add below
import './app.css'; // Import the CSS file


const MainPage = () => {
  const handleSignup = () => {
    // Add your signup logic here (e.g., form submission, API call)
    console.log('Signup button clicked!');
  };

  return (
    <div className="home-container">
      <div className="image-containers">
        <img 
          src={myImage} 
          alt="Main Image" 
          className="full-width-image"
        />
        
        <div className="text-overlay">
          <h1 className="welcome-heading">
            FIGHT LIKE <br /> A <span className="champion-word">CHAMPION</span>
          </h1>
        </div>
      </div>

      {/* White box with three small images */}
      <div className="white-box">
        <div className="small-images-container">
          <div className="small-image-wrapper">
            <img src={smallImage1} alt="Small Image 1" className="small-image" />
            <p className="small-image-caption">PUNCHING-BAG</p>
          </div>
          <div className="small-image-wrapper">
            <img src={smallImage2} alt="Small Image 2" className="small-image" />
            <p className="small-image-caption">SHOES</p>
          </div>
          <div className="small-image-wrapper">
            <img src={smallImage3} alt="Small Image 3" className="small-image" />
            <p className="small-image-caption">WEIGHT</p>
          </div>
        </div>
      </div>

      {/* New content and image together */}
      <div className="new-image-container">
        <img 
          src={newImage} 
          alt="New Image" 
          className="new-image"
        />
        
        <div className="new-content">
          <div className="red-box"> </div>
            <h2 className="new-content-heading">HOW WE GOT STARTED <br />IN THIS BUSINESS</h2>
         
          <p className="new-content-paragraph">
            Becoming a boxing champion requires more than just physical strength—it’s about 
            discipline, strategy, and mental toughness. A champion dedicates hours to perfecting 
            technique, footwork, and timing, all while building endurance and power. Consistent 
            training, sparring, and learning from every fight are key. A great boxer also studies 
            opponents, adapting to their style and weaknesses.
          </p>

          <p className="new-content-paragraph">
            Mental resilience is crucial in the ring; staying focused, handling pressure, and 
            pushing through fatigue define true champions. With determination, hard work, and a 
            never-quit attitude, anyone can rise in the sport and aim for the title of boxing.
          </p>

          {/* Button Container */}
          <div className="button-container">
            <button className="signup-button" onClick={handleSignup}>
              Sign Up
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainPage;
