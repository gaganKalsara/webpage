import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Navbar/navbar';
import Footer from './Footer/footer';
import Home from './components/MainPage';
import Shop from './BoxingPromo/BoxingPromo';
import About from './Boxchamp/Boxchamp';
import Login from './components/Login'; // Import your login component
import Register from './components/Register'; // Import your login component

import './App.css';

const App = () => {
  return (
    <Router>
      <div className="app-container">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/about" element={<About />} />
          <Route path="/login" element={<Login />} /> {/* Add the Login route */}
          <Route path="/register" element={<Register />} /> 
        </Routes>
        <Footer />
      </div>
    </Router>
  );
};

export default App;
