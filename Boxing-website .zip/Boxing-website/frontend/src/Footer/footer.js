import React from 'react';
// Import the PNG icons
import twitterIcon from '../images/6.png';  // Replace with the actual path
import instagramIcon from '../images/7.png';  // Replace with the actual path
import facebookIcon from '../images/8.png';  // Replace with the actual path
import youtubeIcon from '../images/9.png';  // Replace with the actual path

const Footer = () => {
  return (
    <footer style={styles.footer}>
      <div style={styles.content}>
        <h2 style={styles.heading}>
          READY FOR YOYR
          
          <br />
          <span style={styles.nextLesson}>NEXT</span> LESSON?
        </h2>
        <div style={styles.socialIcons}>
          {/* Replace Font Awesome icons with custom PNG icons */}
          <img src={twitterIcon} alt="Twitter" style={styles.icon} />
          <img src={instagramIcon} alt="Instagram" style={styles.icon} />
          <img src={facebookIcon} alt="Facebook" style={styles.icon} />
          <img src={youtubeIcon} alt="YouTube" style={styles.icon} />
        </div>
      </div>
      <div style={styles.bottomRow}>
        <span style={styles.email}>gagankalsara59@gmail.com</span>
        <div>
          <span style={styles.link}>Privacy policy</span>
          <span style={styles.link}>Terms & Conditions</span>
        </div>
      </div>
    </footer>
  );
};

const styles = {
    footer: {
      backgroundColor: '#1a1a1a',
      color: 'white',
      padding: '20px',
      fontFamily: 'Arial, sans-serif',
    },
    content: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '20px',
    },
    heading: {
      marginBottom: '30px',
      fontSize: '40px',
      marginLeft: '120px',
      lineHeight: '1.8',  // Adjusted line-height to reduce space between lines
    },
    nextLesson: {
      color: 'red',
    },
    socialIcons: {
        margin:'50px',
      display: 'flex',
    },
    icon: {
      marginLeft: '25px',
      width: '30px',  // Adjusted width (had a typo in the previous code)
      height: '30px',
      marginBottom: '10px',
      cursor: 'pointer', // Optional: Make icons clickable
    },
    bottomRow: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: '14px',
    },
    email: {
      marginTop: '40px',
      marginLeft: '7%',
      color: 'white',
    },
    link: {
        margin:'50px',
      marginBottom: '30px',
      marginLeft: '20px',
      color: 'white',
    },
  };
  

export default Footer;
