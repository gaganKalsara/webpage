import React from 'react';
import c from '../images/Boxing 7.jpg';
import a from '../images/boxcher.jpg'
import b from '../images/Boxing 8.jpg'
import d from '../images/Boxing 15.png'

const BoxingPromo = () => {
  const styles = {
    // Existing BoxingPromo styles
    container: {
      display: 'flex',
      alignItems: 'center',
      padding: '40px',
      backgroundColor: '#808080',
      color: 'white',
      Width: '1200px',
      margin: '0 auto',
    },
    textSection: {
      flex: 1,
      paddingRight: '40px',
    },
    heading: {
      fontFamily: 'Saira Condensed',
      marginLeft:'90px',
      lineHeight: '1.5',
      fontSize: '6.7rem',
      marginBottom: '90px',
      fontWeight: 'bold',
      color: '#000000',
    },
    goalText: {
      color: '#ff0000',
    },
    paragraph: {
      marginLeft: '90px',
      fontSize: '1.5rem',
      lineHeight: '2',
      marginBottom: '30px',
      fontFamily: 'Saira Condensed',
      textAlign: 'justify',
  },
    button: {
      marginLeft:'90px',
      backgroundColor: '#990000',
      color: 'white',
      border: 'none',
      padding: '15px 30px',
      fontSize: '1.1rem',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
    },
    imageContainer: {
      margin:'60px',
      marginTop:'160px',
      flex: 1,
      borderRadius: '200px 40px 300px 100px',
      overflow: 'hidden',
  },
  image: {
      width: '100%',
      height: '100%',
      display: 'block',
  },
    
    // Best Selling section styles
    bestSellingContainer: {
      padding: '40px 20px',
      maxWidth: '1200px',
      margin: '0 auto',
    },
    header: {
      textAlign: 'center',
      marginBottom: '40px',
    },
    title: {
      fontSize: '2.5rem',
      fontWeight: 'bold',
      marginBottom: '15px',
      color: '#000000',
    },
    subtitle: {
      fontSize: '1.1rem',
      color: '#666',
    },
    productsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '30px',
      marginBottom: '40px',
    },
    productCard: {
      position: 'relative',
      backgroundColor: 'white',
      borderRadius: '8px',
      overflow: 'hidden',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
      transition: 'transform 0.3s ease',
    },
    productImage: {
      width: '360px',
      height: '280px',
      objectFit: 'cover',
    },
    productInfo: {
      padding: '15px',
      backgroundColor: '#f0f0f0',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    productName: {
      fontSize: '1.1rem',
      fontWeight: 'bold',
    },
    cartIcon: {
      cursor: 'pointer',
      fontSize: '1.5rem',
    },
    priceRating: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '10px 15px',
      backgroundColor: '#f0f0f0',
    },
    price: {
      fontWeight: 'bold',
    },
    rating: {
      display: 'flex',
      alignItems: 'center',
    },
    star: {
      color: '#FFD700',
      marginLeft: '5px',
    },
    moreButton: {
      display: 'block',
      width: '200px',
      margin: '0 auto',
      padding: '15px 30px',
      backgroundColor: '#990000',
      color: 'white',
      textAlign: 'center',
      textDecoration: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
      border: 'none',
    },
    popularSection: {
        padding: '40px 20px',
        maxWidth: '1200px',
        margin: '0 auto',
        textAlign: 'center',
      },
      popularHeader: {
        fontSize: '2rem',
        fontWeight: 'bold',
        marginBottom: '10px',
        textTransform: 'uppercase',
      },
      popularSubtitle: {
        fontSize: '1rem',
        color: '#666',
        marginBottom: '40px',
      },
      productCard: {
        backgroundColor: '#f0f0f0',
        borderRadius: '8px',
        overflow: 'hidden',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
        position: 'relative',
        marginBottom: '20px',
      },
      cartButton: {
        backgroundColor: '#333',
        color: 'white',
        border: 'none',
        padding: '8px',
        borderRadius: '50%',
        cursor: 'pointer',
        width: '30px',
        height: '30px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      },
      productDetails: {
        padding: '15px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      },
      exclusiveSection: {
        position: 'relative',
        color: 'white',
        padding: '60px 20px',
        backgroundColor: 'black',
        textAlign: 'right',
    },
    exclusiveContent: {
        maxWidth: '1200px',
        margin: '0 auto',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    exclusiveText: {
       lineHeight: '2',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        marginLeft: '20px',
    },
    exclusiveTitle: {
        fontSize: '6rem',
        fontWeight: 'bold',
        marginBottom: '20px',
        textAlign: 'left',
    },
    exclusiveOffer: {
        fontSize: '6rem',
        color: '#ff0003',
        fontWeight: 'bold',
        textAlign: 'left',
    },
    shopNowButton: {
       
        padding: '20px 30px',
        fontSize: '1.5rem',
        fontWeight: 'bold',
        backgroundColor: 'red',
        color: '#fff',
        border: 'none',
        cursor: 'pointer',
        marginTop: '60px',
    },
  
  };

  const products = [
    {
      id: 1,
      name: 'PUNCHING A',
      price: 10000.00,
      rating: 5.0,
      image: '/api/placeholder/300/400'
    },
    {
      id: 2,
      name: 'PUNCHING B',
      price: 7500.00,
      rating: 5.0,
      image: '/api/placeholder/300/400'
    },
    {
      id: 3,
      name: 'PUNCHING C',
      price: 15000.00,
      rating: 5.0,
      image: '/api/placeholder/300/400'
    },
    {
      id: 4,
      name: 'RDX GLOVES',
      price: 7000.00,
      rating: 5.0,
      image: '/api/placeholder/300/300'
    },
    {
      id: 5,
      name: 'FACE GURDER',
      price: 3500.00,
      rating: 5.0,
      image: '/api/placeholder/300/300'
    },
    {
      id: 6,
      name: 'ADIDAS SIIQUES',
      price: 5000.00,
      rating: 5.0,
      image: '/api/placeholder/300/300'
    }
  ];

  const popularProducts = [
    {
      id: 1,
      name: 'KAPPA SHOUES',
      price: 2000.00,
      rating: 5.0,
      image: '/api/placeholder/300/300'
    },
    {
      id: 2,
      name: 'PUNCHING D',
      price: 1500.00,
      rating: 5.0,
      image: '/api/placeholder/300/300'
    },
    {
      id: 3,
      name: 'PUNCHING E',
      price: 1500.00,
      rating: 5.0,
      image: '/api/placeholder/300/300'
    },
    {
      id: 4,
      name: 'RDX GLOVES',
      price: 7000.00,
      rating: 5.0,
      image: '/api/placeholder/300/300'
    },
    {
      id: 5,
      name: 'GURDER',
      price: 3500.00,
      rating: 5.0,
      image: '/api/placeholder/300/300'
    },
    {
      id: 6,
      name: 'FULL KIT',
      price: 25000.00,
      rating: 5.0,
      image: '/api/placeholder/300/300'
    }
  ];

  return (
    <>
   
      <div style={styles.container}>
        <div style={styles.textSection}>
          <h1 style={styles.heading}>
            COMPLEATE <br/>
            YOUR <br />
            FUTURE <span style={styles.goalText}>GOAL!</span>
          </h1>
          <p style={styles.paragraph}>
            UNLOCK YOUR FULL POTENTIAL IN BOXING WITH DEDICATION, DISCIPLINE, AND HARD WORK. 
            TRAIN LIKE A CHAMPION, MASTER YOUR TECHNIQUE, AND PUSH YOUR LIMITS. STAY FOCUSED, 
            AND WITH RELENTLESS EFFORT, YOU CAN ACHIEVE YOUR DREAM OF BECOMING A BOXING CHAMPION!
          </p>
          <button 
            style={styles.button}
            onMouseOver={(e) => e.target.style.backgroundColor = '#cc0000'}
            onMouseOut={(e) => e.target.style.backgroundColor = '#990000'}
          >
            EXPLORE NOW
          </button>
        </div>
        <div style={styles.imageContainer}>
          <img 
            src={a}
            alt="Boxer in training"
            style={styles.image}
          />
        </div>
      </div>

      <div style={styles.bestSellingContainer}>
        <div style={styles.header}>
          <h2 style={styles.title}>Best Selling</h2>
          <p style={styles.subtitle}>Get in the trend with our curated selection of best-selling styles</p>
        </div>
        
        <div style={styles.productsGrid}>
          {products.map((product) => (
            <div 
              key={product.id} 
              style={styles.productCard}
              onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
              onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}
            >
              <img 
                src={b}
                alt={product.name} 
                style={styles.productImage}
              />
              <div style={styles.productInfo}>
                <span style={styles.productName}>{product.name}</span>
                <span style={styles.cartIcon}>🛒</span>
              </div>
              <div style={styles.priceRating}>
                <span style={styles.price}>${product.price.toFixed(2)}</span>
                <div style={styles.rating}>
                  {product.rating}
                  <span style={styles.star}>⭐</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <button 
          style={styles.moreButton}
          onMouseOver={(e) => e.target.style.backgroundColor = '#cc0000'}
          onMouseOut={(e) => e.target.style.backgroundColor = '#990000'}
        >
          MORE →
        </button>
      </div>

        {/* Popular Products Section */}
        <div style={styles.popularSection}>
        <h2 style={styles.popularHeader}>Populer</h2>
        <p style={styles.popularSubtitle}>
          Stay ahead of the curve with our top-selling, trendsetting styles!
        </p>
        <div style={styles.productsGrid}>
          {popularProducts.map((product) => (
            <div key={product.id} style={styles.productCard}>
              <img 
                src={c}
                alt={product.name}
                style={styles.productImage}
              />
              <div style={styles.productDetails}>
                <div>
                  <div style={styles.productName}>{product.name}</div>
                  <div style={styles.price}>$ {product.price.toFixed(2)}</div>
                </div>
                <div style={styles.rating}>
                  {product.rating} ⭐
                  <button style={styles.cartButton}>🛒</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <button style={styles.moreButton}>MORE →</button>
      </div>

      {/* Exclusive Offer Section */}
      <div style={styles.exclusiveSection}>
  <div style={styles.exclusiveContent}>
    <img 
      src={d}  // Ensure that 'd' is defined correctly as the image source
      alt="Boxer"
      style={{ maxWidth: '100%', height: '600px', borderRadius: '15px' }} // Added borderRadius for a rounded corner effect
    />
    <div style={styles.exclusiveText}>
      <h2 style={styles.exclusiveTitle}>EXCLUSIVE</h2>
      <div style={styles.exclusiveOffer}>OFFER</div>
      <h3 style={{ fontSize: '3.5rem', fontWeight: 'bold' }}>
        50% <span style={{ color: '#ff0000' }}>OFF</span>
      </h3>
      <button style={styles.shopNowButton}>
        SHOP NOW →
      </button>
    </div>
  </div>
</div>

      
    </>
  );
};

export default BoxingPromo;